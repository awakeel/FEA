﻿export const environment = {
  production: true,
  metaDataAPI: 'http://sagssystem/ex_sqlSvc/REST/Service.svc/Entity/DL_CMSView',
  dataAPI: 'http://sagssystem/ex_sqlSvc/REST/Service.svc/Entity/',
  actionsAPI: 'http://sagssystem/ex_sqlSvc/REST/Service.svc/Entity/DL_Action',
  menuIconURL: '/EX_Resources/gif/16X16/',
  local: false
};
