export * from './dynamic-page.component';
