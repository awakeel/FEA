export class DLPage {
  constructor(
    public page: string, public pageTitle: string, pageTemplate: string
  ) { }

}
