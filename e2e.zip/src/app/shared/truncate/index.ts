export { TruncateModule, TRUNCATE_PIPES } from './truncate.module';
