﻿import { DLCMSView } from '../models';
export interface WebpartComponent {
    data: DLCMSView;
  iframeSource ?: any;
  }