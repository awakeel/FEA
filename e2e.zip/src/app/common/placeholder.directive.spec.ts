import { PlaceholderDirective } from './placeholder.directive';

describe('PlaceholderDirective', () => {
  it('should create an instance', () => {
    const directive = new PlaceholderDirective();
    expect(directive).toBeTruthy();
  });
});
