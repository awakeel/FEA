export * from './dynamic-iframe.component';
